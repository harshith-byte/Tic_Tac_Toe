import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTable;
import java.awt.GridBagLayout;
import java.awt.Component;
import javax.swing.Box;
import java.awt.GridBagConstraints;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class play extends JFrame {

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					play frame = new play();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 *
	 */
	private Board board_page =new Board();
	private int x=0;
	private int o=0;
	private String startgame="X";
	private int i=0;
	
	private int b1=10;
	private int b2=10;
	private int b3=10;
	private int b4=10;
	private int b5=10;
	private int b6=10;
	private int b7=10;
	private int b8=10;
	private int b9=10;
	
	private String player1=null;
	private String player2;
	private Component frame;
//	private void playernames() {
//		JOptionPane.showInputDialog("enter player-1 name" ,player1);
//		JOptionPane.showInputDialog("enter player-2 name" ,player2);
//	}

	
	
	private void game() {
		
		if(b1==1 && b2==1 && b3==1) {
			JOptionPane.showMessageDialog(frame, "player X WINS " ,"Winner",JOptionPane.INFORMATION_MESSAGE);
		}
		else if(b4==1 && b5==1 && b6==1) {
			JOptionPane.showMessageDialog(frame, "player X WINS","Winner",JOptionPane.INFORMATION_MESSAGE);
		}
		else if(b7==1 && b8==1 && b9==1) {
			JOptionPane.showMessageDialog(frame, "player X WINS","Winner",JOptionPane.INFORMATION_MESSAGE);
		}
		else if(b1==1 && b4==1 && b7==1) {
			JOptionPane.showMessageDialog(frame, "player X WINS","Winner",JOptionPane.INFORMATION_MESSAGE);
		}
		else if(b2==1 && b5==1 && b8==1) {
			JOptionPane.showMessageDialog(frame, "player X WINS","Winner",JOptionPane.INFORMATION_MESSAGE);
		}
		else if(b3==1 && b6==1 && b9==1) {
			JOptionPane.showMessageDialog(frame, "player X WINS","Winner",JOptionPane.INFORMATION_MESSAGE);
		}
		else if(b1==1 && b5==1 && b9==1) {
			JOptionPane.showMessageDialog(frame, "player X WINS","Winner",JOptionPane.INFORMATION_MESSAGE);
		}
		else if(b3==1 && b5==1 && b7==1) {
			JOptionPane.showMessageDialog(frame, "player X WINS","Winner",JOptionPane.INFORMATION_MESSAGE);
		}
		
		
		else if(b1==0 && b2==0 && b3==0) {
			JOptionPane.showMessageDialog(frame, "player O WINS","Winner",JOptionPane.INFORMATION_MESSAGE);
		}
		else if(b4==0 && b5==0 && b6==0) {
			JOptionPane.showMessageDialog(frame, "player O WINS","Winner",JOptionPane.INFORMATION_MESSAGE);
		}
		else if(b7==0 && b8==0&& b9==0) {
			JOptionPane.showMessageDialog(frame, "player O WINS","Winner",JOptionPane.INFORMATION_MESSAGE);
		}
		else if(b1==0 && b4==0 && b7==0) {
			JOptionPane.showMessageDialog(frame, "player O WINS","Winner",JOptionPane.INFORMATION_MESSAGE);
		}
		else if(b2==0 && b5==0 && b8==0) {
			JOptionPane.showMessageDialog(frame, "player O WINS","Winner",JOptionPane.INFORMATION_MESSAGE);
		}
		else if(b3==0 && b6==0 && b9==0) {
			JOptionPane.showMessageDialog(frame, "player O WINS","Winner",JOptionPane.INFORMATION_MESSAGE);
		}
		else if(b1==0 && b5==0 && b9==0) {
			JOptionPane.showMessageDialog(frame, "player O WINS","Winner",JOptionPane.INFORMATION_MESSAGE);
		}
		else if(b3==0 && b5==0 && b7==0) {
			JOptionPane.showMessageDialog(frame, "player O WINS","Winner",JOptionPane.INFORMATION_MESSAGE);
		}
		
		
		else if(i==9) {
			JOptionPane.showMessageDialog(frame, "Game Draw","TIC TAC TOE",JOptionPane.INFORMATION_MESSAGE);
			i=0;
			
		}
		
	}
	
	private void switchplayers() {
		if(startgame.equalsIgnoreCase("X")) {
			startgame="O";
		}
		else {
			startgame = "X";
		}
	}
	
	
	
	public play() {
		//playernames();
		getContentPane().setFont(new Font("Trebuchet MS", Font.BOLD, 25));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 600, 400);
		getContentPane().setLayout(null);
		
		JButton top_left = new JButton("");
		top_left.setForeground(new Color(153, 51, 0));
		top_left.setFont(new Font("Trebuchet MS", Font.BOLD, 25));
		top_left.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				top_left.setText(startgame);
				if(startgame.equalsIgnoreCase("X")) {
					top_left.setForeground(Color.RED);
					b1=1;
					i++;
				}
				else {
					top_left.setForeground(Color.blue);
					b1=0;
					i++;
				}
				switchplayers();
				game();
			}
		});
		
		
		top_left.setBounds(136, 99, 89, 66);
		getContentPane().add(top_left);
		
		JButton top_mid = new JButton("");
		top_mid.setForeground(new Color(153, 51, 0));
		top_mid.setFont(new Font("Trebuchet MS", Font.BOLD, 25));
		top_mid.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				top_mid.setText(startgame);
				if(startgame.equalsIgnoreCase("X")) {
					top_mid.setForeground(Color.RED);
					b2=1;i++;
				}
				else {
					top_mid.setForeground(Color.blue);
					b2=0;i++;
				}
				switchplayers();
				game();
			}
		});
		top_mid.setBounds(235, 99, 89, 66);
		getContentPane().add(top_mid);
		
		JButton top_right = new JButton("");
		top_right.setForeground(new Color(153, 51, 0));
		top_right.setFont(new Font("Trebuchet MS", Font.BOLD, 25));
		top_right.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				top_right.setText(startgame);
				if(startgame.equalsIgnoreCase("X")) {
					top_right.setForeground(Color.RED);
					b3=1;i++;
				}
				else {
					top_right.setForeground(Color.blue);
					b3=0;i++;
				}
				switchplayers();
				game();
			}
		});
		top_right.setBounds(334, 99, 89, 66);
		getContentPane().add(top_right);
		
		JButton mid_left = new JButton("");
		mid_left.setForeground(new Color(153, 51, 0));
		mid_left.setFont(new Font("Trebuchet MS", Font.BOLD, 25));
		mid_left.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				mid_left.setText(startgame);
				if(startgame.equalsIgnoreCase("X")) {
					mid_left.setForeground(Color.RED);
					b4=1;i++;
				}
				else {
					mid_left.setForeground(Color.blue);
					b4=0;i++;
				}
				switchplayers();
				game();
			}
		});
		mid_left.setBounds(136, 176, 89, 65);
		getContentPane().add(mid_left);
		
		JButton mid_mid = new JButton("");
		mid_mid.setForeground(new Color(153, 51, 0));
		mid_mid.setFont(new Font("Trebuchet MS", Font.BOLD, 25));
		mid_mid.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				mid_mid.setText(startgame);
				if(startgame.equalsIgnoreCase("X")) {
					mid_mid.setForeground(Color.RED);
					b5=1;i++;
				}
				else {
					mid_mid.setForeground(Color.blue);
					b5=0;i++;
				}
				switchplayers();
				game();
			}
		});
		mid_mid.setBounds(235, 177, 89, 64);
		getContentPane().add(mid_mid);
		
		JButton mid_right = new JButton("");
		mid_right.setForeground(new Color(153, 51, 0));
		mid_right.setFont(new Font("Trebuchet MS", Font.BOLD, 25));
		mid_right.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				mid_right.setText(startgame);
				if(startgame.equalsIgnoreCase("X")) {
					mid_right.setForeground(Color.RED);
					b6=1;i++;
				}
				else {
					mid_right.setForeground(Color.blue);
					b6=0;i++;
				}
				switchplayers();
				game();
			}
		});
		mid_right.setBounds(334, 176, 89, 65);
		getContentPane().add(mid_right);
		
		JButton bottom_left = new JButton("");
		bottom_left.setForeground(new Color(153, 51, 0));
		bottom_left.setFont(new Font("Trebuchet MS", Font.BOLD, 25));
		bottom_left.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				bottom_left.setText(startgame);
				if(startgame.equalsIgnoreCase("X")) {
					bottom_left.setForeground(Color.RED);
					b7=1;i++;
				}
				else {
					bottom_left.setForeground(Color.blue);
					b7=0;i++;
				}
				switchplayers();
				game();
			}
			
		});
		bottom_left.setBounds(136, 252, 89, 65);
		getContentPane().add(bottom_left);
		
		JButton bottom_mid = new JButton("");
		bottom_mid.setForeground(new Color(153, 51, 0));
		bottom_mid.setFont(new Font("Trebuchet MS", Font.BOLD, 25));
		bottom_mid.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				bottom_mid.setText(startgame);
				if(startgame.equalsIgnoreCase("X")) {
					bottom_mid.setForeground(Color.RED);
					b8=1;i++;
				}
				else {
					bottom_mid.setForeground(Color.blue);
					b8=0;i++;
				}
				switchplayers();
				game();
			}
		});
		bottom_mid.setBounds(235, 252, 89, 65);
		getContentPane().add(bottom_mid);
		
		JButton bottom_right = new JButton("");
		bottom_right.setForeground(new Color(153, 51, 0));
		bottom_right.setFont(new Font("Trebuchet MS", Font.BOLD, 25));
		bottom_right.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				bottom_right.setText(startgame);
				if(startgame.equalsIgnoreCase("X")) {
					bottom_right.setForeground(Color.RED);
					b9=1;i++;
				}
				else {
					bottom_right.setForeground(Color.blue);
					b9=0;i++;
				}
				switchplayers();
				game();
			}
		});
		bottom_right.setBounds(334, 252, 89, 65);
		getContentPane().add(bottom_right);
		
		JButton btnNewButton = new JButton("RESET");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				top_left.setText(null);
				top_mid.setText(null);
				top_right.setText(null);
				mid_left.setText(null);
				mid_mid.setText(null);
				mid_right.setText(null);
				bottom_left.setText(null);
				bottom_mid.setText(null);
				bottom_right.setText(null);
				b1=10;
				b2=10;
				b3=10;
				b4=10;
				b5=10;
				b6=10;
				b7=10;
				b8=10;
				b9=10;
				i=0;
				
				
			}
		});
		btnNewButton.setFont(new Font("Trebuchet MS", Font.BOLD, 20));
		btnNewButton.setBounds(455, 252, 106, 65);
		getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("GAME");
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setFont(new Font("Trebuchet MS", Font.BOLD, 25));
		lblNewLabel.setBounds(246, 42, 70, 24);
		getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				dispose();
				board_page.frame_board.setVisible(true);
			}
		});
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\HARSHITH\\eclipse-workspace\\TICTOC\\image\\arrow-back-icon.png"));
		lblNewLabel_1.setBounds(10, 0, 48, 53);
		getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setIcon(new ImageIcon("C:\\Users\\HARSHITH\\eclipse-workspace\\TICTOC\\image\\Play background.jpg"));
		lblNewLabel_2.setBounds(0, 0, 584, 361);
		getContentPane().add(lblNewLabel_2);
	}
}

