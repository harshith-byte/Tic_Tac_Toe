import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;
import javax.swing.SwingConstants;
import javax.swing.JTextArea;
import javax.swing.UIManager;
import javax.swing.ImageIcon;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class about extends JFrame {

	private JPanel contentPane;
	private Board board_page =new Board();
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					about frame = new about();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public about() {
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 600, 400);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("About");
		lblNewLabel.setForeground(new Color(255, 255, 0));
		lblNewLabel.setBackground(new Color(0, 128, 128));
		lblNewLabel.setFont(new Font("Trebuchet MS", Font.BOLD, 22));
		lblNewLabel.setBounds(244, 42, 72, 24);
		contentPane.add(lblNewLabel);
		
		JTextArea txtrTicTacToe = new JTextArea();
		txtrTicTacToe.setFont(new Font("Trebuchet MS", Font.BOLD, 13));
		txtrTicTacToe.setEditable(false);
		txtrTicTacToe.setForeground(new Color(0, 0, 0));
		txtrTicTacToe.setBackground(new Color(204, 102, 51));
		txtrTicTacToe.setText("TIC TAC TOE a game played between two players . It's fun to play and there is \r\nprobability associated in the game based on who wins the game.\r\n\r\nThis is just a try to build a game on computer as a application");
		txtrTicTacToe.setBounds(39, 131, 487, 80);
		contentPane.add(txtrTicTacToe);
		
		JButton btnNewButton = new JButton("");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				board_page.frame_board.setVisible(true);
			}
		});
		btnNewButton.setBackground(new Color(222, 184, 135));
		btnNewButton.setIcon(new ImageIcon("C:\\Users\\HARSHITH\\eclipse-workspace\\TICTOC\\image\\arrow-back-icon.png"));
		btnNewButton.setBounds(10, 11, 89, 55);
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel_1 = new JLabel("New label");
		lblNewLabel_1.setBackground(new Color(222, 184, 135));
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\HARSHITH\\eclipse-workspace\\TICTOC\\image\\brown_autumn_leaves_200461.jpg"));
		lblNewLabel_1.setBounds(0, 0, 584, 361);
		contentPane.add(lblNewLabel_1);
	}
}
